import React from 'react';

const MiniBanner = () => {
  return <div className="mini-banner w-100 back-fixed"></div>;
};

export default MiniBanner;
